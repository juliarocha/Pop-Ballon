//
//  BackButton.swift
//  Pop Balloon
//
//  Created by Nathalia Inacio on 10/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit

class BackButton:SKSpriteNode {
    
    let myBackButton:SKTexture = SKTexture(imageNamed: "back")
    
    
    init() {
        
        let myBackButtonTexture = myBackButton
        super.init(texture: myBackButtonTexture, color: .clear, size: myBackButtonTexture.size())
        self.position = CGPoint(x: -300, y: 640)
        self.zPosition = 6
        self.setScale(0.2)
        self.name = "backGame"
        
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}


