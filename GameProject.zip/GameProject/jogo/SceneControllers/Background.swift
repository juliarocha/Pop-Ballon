//
//  Background.swift
//  jogo
//
//  Created by Julia Rocha on 03/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit

class Background:SKSpriteNode {
    
    let myBackgrounds:[SKTexture] = [SKTexture(imageNamed: "background1"), SKTexture(imageNamed: "background2"), SKTexture(imageNamed: "background3"), SKTexture(imageNamed: "background4")]
    
    
    init(level:Int) {
       
        let myBackgroundTexture = myBackgrounds[level - 1]
        super.init(texture: myBackgroundTexture, color: .clear, size: myBackgroundTexture.size())
        self.position = CGPoint(x: self.position.x , y: self.position.y - 50)
        self.zPosition = -1
        
        
        
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
