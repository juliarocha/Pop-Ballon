//
//  Balloon.swift
//  jogo
//
//  Created by Julia Rocha on 02/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit
import AVFoundation

class Balloon:SKSpriteNode {
    
 
    private var bike:Bike
    var rope:Rope!
    var myScene:GameScene
   
    
    private var popFrames:[SKTexture] {
        return [SKTexture(imageNamed: myColor+2), SKTexture(imageNamed: myColor+3), SKTexture(imageNamed: myColor+4)]
    }
    var myColor:String
    
    
    let gravityCategory: UInt32 = 0x1 << 0

    

    
    var player1: AVAudioPlayer?
    var player2: AVAudioPlayer?
    var player3: AVAudioPlayer?

    
    let possibleColors = [ "red", "green", "pink", "purple", "yellow"]
    
    
    init(position:CGPoint, bike:Bike, myScene:GameScene) {
        let randomColorIndex = Int(arc4random_uniform(UInt32(possibleColors.count)))
        self.myColor = possibleColors[randomColorIndex]
        let myColorTexture = SKTexture(imageNamed: myColor)
        self.bike = bike
        self.myScene = myScene

        super.init(texture: myColorTexture, color: .clear, size: myColorTexture.size())
        self.physicsBody = SKPhysicsBody(circleOfRadius: 40)
        self.physicsBody?.affectedByGravity = false
        
        self.physicsBody?.fieldBitMask = gravityCategory + 1
        self.physicsBody?.contactTestBitMask = 0x1 << 5
        self.zPosition = 2
        
        self.position = position
        self.name = myColor
        self.physicsBody?.mass = 7
        
        let timer = Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { (timer) in
            self.esvaziar
        }
        
        self.rope = Rope(balao: self, bike: bike)
        self.rope.physicsBody?.affectedByGravity = false
        self.rope.physicsBody?.fieldBitMask = 0x1 << 3
        self.rope.alpha = 1
        
        let jointA = SKPhysicsJointFixed.joint(withBodyA: (rope.physicsBody)!, bodyB: (bike.physicsBody)!, anchor: (bike.anchorPoint))
        let jointB = SKPhysicsJointFixed.joint(withBodyA: (self.physicsBody)!, bodyB: (rope.physicsBody)!, anchor: (self.anchorPoint))
    
        self.myScene.addChild(rope)
        self.myScene.addChild(self)
        self.myScene.physicsWorld.add(jointA)
        self.myScene.physicsWorld.add(jointB)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    convenience init(from oldBalloon:Balloon, myScene:GameScene) {
        let newPosition = oldBalloon.position.randomPoint(for: 100)
        self.init(position: newPosition, bike: oldBalloon.bike, myScene: myScene)
        self.alpha = 0
        self.rope.alpha = 0
        self.physicsBody?.applyForce(CGVector(dx: 0, dy: 0.2))
        self.inflate
        
        
    }
    
    var pop:Void {
        
   
        
        let popAnime = SKAction.run {
            self.run(SKAction.repeat(SKAction.animate(with: self.popFrames, timePerFrame: 1.0, resize: false, restore: false), count: 1))
            self.run(SKAction.fadeIn(withDuration: 1.0))
            self.popSound()
        }
        let popToAlem = SKAction.run {
            self.alpha = 0
            self.rope.alpha = 0
        }
        let go = SKAction.run {
            self.hidra
            
        }
        let finalSequence = SKAction.sequence([popAnime, popToAlem, go])
        self.run(finalSequence)
        
    }
    
    var hidra:Void {
        self.run(SKAction.wait(forDuration: 2))
        let newBallon = Balloon(from: self, myScene: myScene)
        let anotherNewBalloon = Balloon(from: self, myScene: myScene)
        newBallon.physicsBody?.fieldBitMask = gravityCategory
        newBallon.physicsBody?.fieldBitMask = gravityCategory

//        self.parent?.addChild(newBallon)
//        self.parent?.addChild(anotherNewBalloon)
        self.removeFromParent()
        

    }
    
    var inflate:Void {
        let wait = SKAction.wait(forDuration: 2)
        let alphaNo = SKAction.run {
            self.alpha = 0
            self.rope.alpha = 0
            self.physicsBody?.fieldBitMask = self.gravityCategory + 1
            
        }
        let alphaYes = SKAction.run {
            self.alpha = 1
            self.rope.alpha = 1
            self.physicsBody?.fieldBitMask = self.gravityCategory
            
        }
        let beSmall = SKAction.run {
            self.setScale(0)
            
        }
        let toFront = SKAction.run {
            self.zPosition = 2
        }
        let beBigAgain = SKAction.run {
            self.run(SKAction.scale(to: 1, duration: 1.5))
            self.inflateSound()
        }
        let sequence = SKAction.sequence([alphaNo, wait, beSmall, toFront, alphaYes, beBigAgain])
        run(sequence)
    }
    
    var esvaziar:Void {
         let wait = SKAction.wait(forDuration: 3)
        let alphaNo = SKAction.run {
            self.alpha = 0
            self.removeFromParent()
            
        }
        let beSmall = SKAction.run {
            self.run(SKAction.scale(to: 0, duration: 3))
            self.run(SKAction.move(to: CGPoint(x: self.position.x, y: self.position.y - 50), duration: 3))
            self.rope.run(SKAction.fadeAlpha(to: 0, duration: 3))
            self.deflateflateSound()

        }
        let sequence = SKAction.sequence([beSmall, wait, alphaNo])
        run(sequence)
    }
    
    
        //SOM DO BALAO
    func popSound() {
        guard let url = Bundle.main.url(forResource: "pop", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player1 = try AVAudioPlayer(contentsOf: url, fileTypeHint: "mp3")
            
            guard let player = player1 else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func inflateSound() {
        guard let url = Bundle.main.url(forResource: "inflate", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player2 = try AVAudioPlayer(contentsOf: url, fileTypeHint: "mp3")
            
            guard let player = player2 else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    
    func deflateflateSound() {
        guard let url = Bundle.main.url(forResource: "deflate", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player3 = try AVAudioPlayer(contentsOf: url, fileTypeHint: "mp3")
            
            guard let player = player3 else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    override func removeFromParent() {
        self.rope.removeFromParent()
        super.removeFromParent()
    }
    
    
   
}
