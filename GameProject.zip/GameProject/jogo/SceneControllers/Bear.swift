//
//  Bear.swift
//  jogo
//
//  Created by Julia Rocha on 03/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit
import AVFoundation

class Bear:SKSpriteNode {
    
    var myBear:String
    
    
    var player1: AVAudioPlayer?

    
    
    
    var sadBearFrames:[SKTexture] {
        var myTextureName:String
        var sadTextures:[SKTexture] = []
        for i in 1 ... 30 {
            myTextureName = "sad\(i)"+myBear
            sadTextures.append(SKTexture(imageNamed: myTextureName))
        }
        return sadTextures
    }
    
    var happyBearFrames:[SKTexture] {
        var myTextureName:String
        var happyTextures:[SKTexture] = []
        for i in 1 ... 10 {
            myTextureName = "happy\(i)"+myBear
            happyTextures.append(SKTexture(imageNamed: myTextureName))
        }
        return happyTextures
    }
    
    var puffBearFrames:[SKTexture] {
        var myTextureName:String
        var puffTextures:[SKTexture] = []
        for i in 1 ... 2 {
            myTextureName = "happy\(i)"+myBear
            puffTextures.append(SKTexture(imageNamed: myTextureName))
        }
        return puffTextures
    }
    
  
    let myBears:[SKTexture] = [SKTexture(imageNamed: "bear1"), SKTexture(imageNamed: "bear2"), SKTexture(imageNamed: "bear3"), SKTexture(imageNamed: "bear4")]
    let myPossibleBears:[String] = [ "bear1", "bear2", "bear3", "bear4"]
    
    
    init(level:Int) {
        let index = level - 1
        let myBearTexture = myBears[index]
        self.myBear = myPossibleBears[index]
        super.init(texture: myBearTexture, color: .clear, size: myBearTexture.size())
        self.setScale(0.3)
        self.zPosition = 2
        switch level {
        case 3:
            self.setScale(0.29)
            self.position = CGPoint(x: 135, y: -390)
            
        case 4:
            self.setScale(0.32)
            self.position = CGPoint(x: 170, y: -450)
            
        default:
            self.position = CGPoint(x: 160, y: -450)
        }
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var makeHappy:Void {
        self.run(SKAction.repeat(SKAction.animate(with: self.happyBearFrames, timePerFrame: 0.2, resize: false, restore: true), count: 1))
    }
    
    var makeSad:Void {
        self.run(SKAction.repeat(SKAction.animate(with: self.sadBearFrames, timePerFrame: 0.1, resize: false, restore: true), count: 1))
    }
    
    var makePuff:Void {
        self.run(SKAction.repeat(SKAction.animate(with: self.puffBearFrames, timePerFrame: 0.2, resize: false, restore: true), count: 1))
        self.puffSound()
    }
    
    var makePop:Void{
        let wait = SKAction.wait(forDuration: 3)
        let makeHappy = SKAction.run {
            self.makeHappy
        }
        let makeSad = SKAction.run {
            
            self.makeSad
        }
        let sequence = SKAction.sequence([makeHappy, wait, makeSad])
        run(sequence)
    }
    
    func puffSound() {
        guard let url = Bundle.main.url(forResource: "squick", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player1 = try AVAudioPlayer(contentsOf: url, fileTypeHint: "mp3")
            
            guard let player = player1 else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    
    
    
}
