//
//  BeginController.swift
//  jogo
//
//  Created by Julia Rocha on 19/05/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import SpriteKit
import GameplayKit
import AVFoundation

class BeginController: SKScene {
    
    private var pop1:SKSpriteNode?
    private var goToTutorial:SKSpriteNode?

    
    override func didMove(to view: SKView) {
        
        self.pop1 = self.childNode(withName: "//pop1") as? SKSpriteNode
        self.goToTutorial = self.childNode(withName: "//lblTutorial") as? SKSpriteNode
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch:UITouch = touches.first!
        let positionInScene = touch.location(in: self)
        let touchedNode = self.atPoint(positionInScene)
        
        //INICIAR O JOGO
        if touchedNode.name == "pop1" {
            
            touchedNode.zPosition = -5
            goToTutorial?.zPosition = -5
            let wait = SKAction.wait(forDuration: 0.1)
            let goNext = SKAction.run {
                let newScene = BeginController(fileNamed: "GameScene")
                self.scene?.view?.presentScene(newScene!, transition: SKTransition.fade(withDuration: 2))
                }
            let waitAndGo = SKAction.sequence([wait, goNext])
            run(waitAndGo)
        }
        
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
    
}
