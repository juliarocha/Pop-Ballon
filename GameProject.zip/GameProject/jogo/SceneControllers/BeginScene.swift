//
//  BeginScene.swift
//  jogo
//
//  Created by Julia Rocha on 19/05/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//


import SpriteKit
import GameplayKit
import AVFoundation

class BeginScene: SKScene {
    
    private var pop1:SKSpriteNode?
    private var tut:SKSpriteNode?
    private var play:SKSpriteNode?
    
    override func didMove(to view: SKView) {
        
        self.pop1 = self.childNode(withName: "//pop1") as? SKSpriteNode
        self.tut = self.childNode(withName: "//tut") as? SKSpriteNode
        self.play = self.childNode(withName: "//play") as? SKSpriteNode
        self.pop1?.zPosition = -1
        self.tut?.zPosition = 1
        self.play?.zPosition =  1
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch:UITouch = touches.first!
        let positionInScene = touch.location(in: self)
        let touchedNode = self.atPoint(positionInScene)
        

        if touchedNode.name == "tut" {
            //SCENE TRANSITION
            let goNext = SKAction.run {
                let newScene = TutorialScene(fileNamed: "TutorialScene")
                newScene?.scaleMode = .aspectFill
                self.scene?.view?.presentScene(newScene!, transition: SKTransition.fade(withDuration: 1))
            }
            run(goNext)
            
        }
        
        else{
            
            if touchedNode.name == "play" {
                //SCENE TRANSITION
                let goNext = SKAction.run {
                    let newScene = GameScene(fileNamed: "GameScene")
                    newScene?.scaleMode = .aspectFill
                    self.scene?.view?.presentScene(newScene!, transition: SKTransition.fade(withDuration: 1))
                }
                run(goNext)
                
            }
            
            
        }
        
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }


}
