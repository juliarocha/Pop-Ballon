//
//  Bike.swift
//  jogo
//
//  Created by Julia Rocha on 03/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit


class Bike:SKSpriteNode {
    
    let myBikes:[SKTexture] = [SKTexture(imageNamed: "bike1"), SKTexture(imageNamed: "bike2"), SKTexture(imageNamed: "bike3"), SKTexture(imageNamed: "bike4")]
    let myMasses:[Int] = [70, 120, 140, 150]
    let bikeName:[String] = ["bike1", "bike2", "bike3", "bike4"]
    
    let collisionCategory: UInt32 = 0x1 << 2
    let bikeCategory: UInt32 = 0x1 << 1
    let gravityCategory: UInt32 = 0x1 << 3
    
    init(level:Int) {
        
        //BIKE
        let myBikeTexture = myBikes[level - 1]
        super.init(texture: myBikeTexture, color: .clear, size: myBikeTexture.size())
        self.physicsBody = SKPhysicsBody(rectangleOf: myBikeTexture.size())
        self.physicsBody?.affectedByGravity = true
        self.physicsBody?.mass = CGFloat(myMasses[level - 1])
        self.name = bikeName[level - 1]
        self.position = CGPoint(x: -50, y: 30)
        self.zPosition = 3
        self.physicsBody?.fieldBitMask =  gravityCategory
        self.physicsBody?.contactTestBitMask = self.collisionCategory
        switch self.name {
        case "bike1":
            self.setScale(0.7)
        case "bike4":
            self.setScale(0.7)
        default:
            self.setScale(0.6)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
