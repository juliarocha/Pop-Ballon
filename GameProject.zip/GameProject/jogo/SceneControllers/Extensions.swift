//
//  Extensions.swift
//  jogo
//
//  Created by Julia Rocha on 02/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit

public extension Float {
    
    /// Returns a random floating point number between 0.0 and 1.0, inclusive.
    public static var random: Float {
        return Float(arc4random()) / 0xFFFFFFFF
    }
    
    public static func random(min: Float, max: Float) -> Float {
        return Float.random * (max - min) + min
    }
    
}

public extension CGFloat {
    
    /// Randomly returns either 1.0 or -1.0.
    public static var randomSign: CGFloat {
        return (arc4random_uniform(2) == 0) ? 1.0 : -1.0
    }
}

extension CGPoint {
    func randomPoint(for radius:Double)->CGPoint {
        let rnd = Double(Float.random(min: -2, max: 2))
        let y = CGFloat.randomSign
        var newX:CGFloat = 0
        if y == -1.0 {
            newX = self.x - CGFloat(radius * cos(rnd))
        }
        else {
            newX = self.x + CGFloat(radius * cos(rnd))
        }
        var newY = self.y + CGFloat(radius * sin(rnd))
        
        if newY < self.y {
            newY += 100
        }
        
        return CGPoint(x: newX, y: newY)
    }
}

func +(lhs:String, rhs:Int)->String {
    return lhs+String(rhs)
}


