//
//  Final.swift
//  jogo
//
//  Created by Julia Rocha on 19/05/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import SpriteKit
import GameplayKit
import AVFoundation


class Final: SKScene {

    
    
    
    override func didMove(to view: SKView) {
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
    
}
