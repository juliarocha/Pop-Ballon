//
//  GameScene.swift
//  jogo
//
//  Created by Julia Rocha on 14/05/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import SpriteKit
import GameplayKit
import AVFoundation

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    
    private var bicycle:Bike?
    private var bear:Bear?
    private var currentBackground:SKSpriteNode?
    private var currentLevel:Int?
    
    private let endTexture = SKTexture(imageNamed: "endGameOver")
    private let theEndTexture = SKTexture(imageNamed: "theEndGameOver")
    private let nextTexture = SKTexture(imageNamed: "endNextLevel")
    
    
    
    
    var nextGameNode:SKSpriteNode?
    var endGameOver:SKSpriteNode?
    var theEndNode:SKSpriteNode?

    let gravityCategory: UInt32 = 0x1 << 0
    
    var gravityNode:SKFieldNode?
    
    let collisionCategory:UInt32 = 0x1 << 2
    
    
    
    override func didMove(to view: SKView) {
        
        self.backgroundColor = .gray

        

        displayPossibleLevels()
        
        
        let gravityVector = vector_float3(x: 0, y: 5, z: 0)
        
        self.gravityNode = SKFieldNode.linearGravityField(withVector: gravityVector)
        
        gravityNode?.categoryBitMask = gravityCategory
//        self.gravityNode?.smoothness = 10
        self.gravityNode?.strength = 1
       

    }


    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch:UITouch = touches.first!
        let positionInScene = touch.location(in: self)
        let touchedNode = self.atPoint(positionInScene)
        
        if let nivel = touchedNode as? LevelButton {
            scene?.removeAllChildren()
            self.currentLevel = Int(nivel.name!)!
            levelManager(level: currentLevel!)
            self.addChild(gravityNode!)
            
            
        }
        
        if let balloon = touchedNode as? Balloon {
            balloon.pop
            bear?.makePop
            
            
            
        }
        
        if let urso = touchedNode as? Bear {
            urso.makePuff
        }
        
        if touchedNode.name == "nextlevel" {
            self.removeAllChildren()
            self.currentLevel! += 1
            levelManager(level: currentLevel!)
            self.addChild(gravityNode!)
        }
    
        if touchedNode.name == "tryagain"{
            self.removeAllChildren()
            levelManager(level: currentLevel!)
            self.addChild(gravityNode!)
        }
        
        if touchedNode.name == "menu" || touchedNode.name == "backTT"{
            let goNext = SKAction.run {
                let newScene = BeginScene(fileNamed: "BeginScene")
                newScene?.scaleMode = .aspectFill
                self.scene?.view?.presentScene(newScene!, transition: SKTransition.fade(withDuration: 1))
            }
            run(goNext)
        }
        
        if touchedNode.name == "backGame" {
            self.removeAllChildren()
            displayPossibleLevels()
        }
        
        
        
    }
    
    func levelManager(level:Int) {
        //fisica da cena
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -0.3)
        self.physicsWorld.contactDelegate = self
        
        let outOfScreen = SKSpriteNode(texture: SKTexture(imageNamed: "testOutOfScreen"))
        outOfScreen.position = CGPoint(x: 0, y: 1100)
        outOfScreen.physicsBody = SKPhysicsBody(rectangleOf: outOfScreen.size, center: outOfScreen.anchorPoint)
        outOfScreen.physicsBody?.affectedByGravity = false
        outOfScreen.physicsBody?.contactTestBitMask = self.collisionCategory
        outOfScreen.physicsBody?.fieldBitMask =  0x1 << 3

        outOfScreen.name = "test"
        self.addChild(outOfScreen)
        
        let backbutton = BackButton()
        self.addChild(backbutton)
        
        
        //nodes elementos
        self.bicycle = Bike(level: level)
        self.addChild(bicycle!)
        
        _ = Balloon(position: CGPoint(x: -73, y: 380), bike: bicycle!, myScene: self)

        self.bear = Bear(level: level)
        self.currentBackground = Background(level: level)
        self.currentBackground?.size = self.size
        self.addChild(Grass(level: level))
        self.addChild(bear!)
        self.addChild(currentBackground!)

        
        
        
    }
    
    func displayPossibleLevels() {
        let background = SKSpriteNode(texture: SKTexture(imageNamed: "levelBackground"), color: .clear, size: SKTexture(imageNamed: "levelBackground").size())
        background.zPosition = -1
        background.size = self.size
        background.position = CGPoint(x: background.position.x, y: background.position.y - 50 )

        
        let backButton = SKSpriteNode(texture: SKTexture(imageNamed: "back"))
        backButton.position = CGPoint(x: -300, y: 640)
        backButton.setScale(0.2)
        backButton.zPosition = 6
        backButton.name = "backTT"
        self.addChild(backButton)
        
        let level1Node:SKSpriteNode = LevelButton(Level: 1, Position: CGPoint(x: 230, y: 445))
        let level2Node:SKSpriteNode = LevelButton(Level: 2, Position: CGPoint(x: -230, y: 200))
        let level3Node:SKSpriteNode = LevelButton(Level: 3, Position: CGPoint(x: 250, y: 0))
        let level4Node:SKSpriteNode = LevelButton(Level: 4, Position: CGPoint(x: -170, y: -250))
        self.addChild(background)
        self.addChild(level1Node)
        self.addChild(level2Node)
        self.addChild(level3Node)
        self.addChild(level4Node)

    }
    

    func didBegin(_ contact: SKPhysicsContact) {
        
        let menu = SKSpriteNode(texture: SKTexture(imageNamed: "menu"))
        let tryagain = SKSpriteNode(texture: SKTexture(imageNamed: "tryagain"))
        let nextlevel = SKSpriteNode(texture: SKTexture(imageNamed: "nextlevel"))
        
        menu.name = "menu"
        tryagain.name = "tryagain"
        nextlevel.name = "nextlevel"
        
        if contact.bodyA.node?.name == "grass" || contact.bodyB.node?.name == "grass" {
            let wait = SKAction.wait(forDuration: 1)

            let tela = SKAction.run {
                self.removeAllChildren()
                self.addChild(self.currentBackground!)
                self.endGameOver = SKSpriteNode(texture: self.endTexture)
                self.endGameOver?.name = "end"
                self.endGameOver?.size = self.size
                self.endGameOver?.position = CGPoint(x: (self.endGameOver?.position.x)!, y: (self.endGameOver?.position.y)! - 50 )
                tryagain.position = CGPoint(x: 0 , y: 370 )
                tryagain.zPosition = 4
                self.addChild(tryagain)
                self.addChild(self.endGameOver!)
                
            }
            let sequence = SKAction.sequence([wait, tela])
            run(sequence)
        }

        if contact.bodyA.node?.name == "test" || contact.bodyB.node?.name == "test" {
            
            let wait = SKAction.wait(forDuration: 1)
            
            let tela = SKAction.run {
                
                if self.currentLevel == 4 {
                    self.removeAllChildren()
                    self.addChild(self.currentBackground!)
                    self.theEndNode = SKSpriteNode(texture: self.theEndTexture)
                    self.theEndNode?.name = "theEnd"
                    self.theEndNode?.zPosition = 5
                    self.theEndNode?.size = self.size
                    self.theEndNode?.position = CGPoint(x: (self.theEndNode?.position.x)!, y: (self.theEndNode?.position.y)! - 50 )
                    menu.position = CGPoint(x: 0 , y: 350)
                    menu.zPosition = 6
                    self.addChild(menu)
                    self.addChild(self.theEndNode!)
                }
                else {
                    self.removeAllChildren()
                    self.addChild(self.currentBackground!)
                    self.nextGameNode = SKSpriteNode(texture: self.nextTexture)
                    self.nextGameNode?.zPosition = 3
                    self.nextGameNode?.size = self.size
                    self.nextGameNode?.position = CGPoint(x: (self.nextGameNode?.position.x)!, y: (self.nextGameNode?.position.y)! - 50 )
                    self.nextGameNode?.name = "next"
                    nextlevel.position = CGPoint(x: 0 , y: 370 )
                    nextlevel.zPosition = 4
                    self.addChild(nextlevel)
                    self.addChild(self.nextGameNode!)
                }
            }
            let sequence = SKAction.sequence([wait, tela])
            run(sequence)
            
        }


    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
 

}

