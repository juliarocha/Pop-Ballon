//
//  Grass.swift
//  jogo
//
//  Created by Julia Rocha on 03/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit

class Grass:SKSpriteNode {
    
    let grassCategory: UInt32 = 0x1 << 1
    let bikeCategory: UInt32 = 0x1 << 2

    let collisionCategory:UInt32 = 0x1 << 2


    
    let myGrasses:[SKTexture] = [SKTexture(imageNamed: "grass1"), SKTexture(imageNamed: "grass2"), SKTexture(imageNamed: "grass3"), SKTexture(imageNamed: "grass4")]
    
    
    init(level:Int) {
      
        let myGrassTexture = myGrasses[level - 1]
        super.init(texture: myGrassTexture, color: .clear, size: myGrassTexture.size())
        self.physicsBody = SKPhysicsBody(texture: (self.texture)!, size: CGSize(width: myGrassTexture.size().width, height: myGrassTexture.size().height - 170) )
        self.physicsBody?.affectedByGravity = false
        self.physicsBody?.isDynamic = false
        self.position = CGPoint(x: -4, y: -650)
        self.zPosition = 0
        self.name = "grass"
        self.physicsBody?.contactTestBitMask = self.collisionCategory
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
