//
//  LevelButton.swift
//  jogo
//
//  Created by Julia Rocha on 03/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit

class LevelButton:SKSpriteNode {
    
    let myPossibleLevels:[SKTexture] = [SKTexture(imageNamed: "level1"), SKTexture(imageNamed: "level2"), SKTexture(imageNamed: "level3"), SKTexture(imageNamed: "level4") ]

    
    init(Level:Int, Position:CGPoint) {
        let myLevelTexture = myPossibleLevels[Level - 1]
        super.init(texture: myLevelTexture, color: .clear, size: myLevelTexture.size())
        self.position = Position
        self.name = String(Level)
        
    }
    

    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
