//
//  BaloonManager.swift
//  jogo
//
//  Created by Julia Rocha on 03/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit

class LevelConstructor {
//    
//    var gameScene:SKScene
//    
//    let level1Node:SKSpriteNode = LevelButton(Level: 1, Position: CGPoint(x: -160, y: 240))
//    let grassNode:SKSpriteNode = Grass()
//    let firstBalloon:SKSpriteNode = Balloon(position: CGPoint(x: -73, y: 380))
//
//
//    init(gamescene:SKScene, level: Int) {
//        self.gameScene = gamescene
//        
//        
//
//    }
//    public func addBalloon(balloon:Balloon, bike:Bike, scene:SKScene) {
//        balloon.run(SKAction.wait(forDuration: 1))
//        let newBalloon = Balloon(from: balloon)
//        let anotherNewBalloon = Balloon(from: balloon)
//        scene.addChild(newBalloon)
//        scene.addChild(anotherNewBalloon)
//        balloon.removeFromParent()
//        
//        let newBalloonRope = Rope(Balao: newBalloon, Bike: bike)
//        let anotherNewBalloonRope = Rope(Balao: anotherNewBalloon, Bike: bike)
//        
//        scene.addChild(newBalloonRope)
//        scene.addChild(anotherNewBalloonRope)
//        
//        
//        let jointNewBalloonRopeToBike = SKPhysicsJointFixed.joint(withBodyA: (bike.physicsBody)!, bodyB: (newBalloonRope.physicsBody)!, anchor: (bike.anchorPoint))
//        let jointNewBalloonRopeToNewBalloon = SKPhysicsJointFixed.joint(withBodyA: (newBalloon.physicsBody)!, bodyB: (newBalloonRope.physicsBody)!, anchor: (newBalloon.anchorPoint))
//        scene.physicsWorld.add(jointNewBalloonRopeToNewBalloon)
//        scene.physicsWorld.add(jointNewBalloonRopeToBike)
//        
//        
//        let jointAnotherNewBalloonRopeToBike = SKPhysicsJointFixed.joint(withBodyA: (bike.physicsBody)!, bodyB: (anotherNewBalloonRope.physicsBody)!, anchor: (bike.anchorPoint))
//        let jointAnotherNewBalloonRopeToNewBalloon = SKPhysicsJointFixed.joint(withBodyA: (anotherNewBalloon.physicsBody)!, bodyB: (anotherNewBalloonRope.physicsBody)!, anchor: (anotherNewBalloon.anchorPoint))
//        scene.physicsWorld.add(jointAnotherNewBalloonRopeToNewBalloon)
//        scene.physicsWorld.add(jointAnotherNewBalloonRopeToBike) 
//    }
}
