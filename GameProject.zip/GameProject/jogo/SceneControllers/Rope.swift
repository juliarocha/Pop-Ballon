//
//  Rope.swift
//  jogo
//
//  Created by Julia Rocha on 03/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit

class Rope:SKShapeNode {

    init(balao:Balloon, bike:Bike) {
        var endPoint:CGPoint
        switch bike.name {
        case "bike2":
            
            endPoint = CGPoint(x: bike.position.x - 30, y: bike.position.y - 75)
            
        case "bike3":
            
            endPoint = CGPoint(x: bike.position.x + 40, y: bike.position.y + 100)
            
        case "bike4":
            
            endPoint = CGPoint(x: bike.position.x, y: bike.position.y)
            
        default:
            endPoint = CGPoint(x: bike.position.x, y: bike.position.y + 10)

        }
        
        let startPoint:CGPoint = CGPoint(x: balao.position.x, y: balao.position.y - balao.size.height/2 + 5)
        
        super.init()
        // Create line with SKShapeNode
        
        let path = UIBezierPath()
        path.move(to: startPoint)
        path.addLine(to: endPoint)
        self.path = path.cgPath
        self.strokeColor = UIColor.black
        self.lineWidth = 2
        self.zPosition = 1
        self.alpha = 0
        
        self.physicsBody  = SKPhysicsBody(rectangleOf: CGSize(width: abs(endPoint.x - startPoint.x), height: abs(endPoint.y - startPoint.y)))
        self.physicsBody?.contactTestBitMask = 0x01 << 8


//        let addJointRtBk = SKPhysicsJointFixed.joint(withBodyA: (self.physicsBody)!, bodyB: (bike.physicsBody)!, anchor: (bike.anchorPoint))
//        let addJointRtBa = SKPhysicsJointFixed.joint(withBodyA: (balao.physicsBody)!, bodyB: (self.physicsBody)!, anchor: (balao.anchorPoint))
//
//        if let scene = self.parent?.parent as! SKScene? {
//            scene.physicsWorld.add(addJointRtBk)
//            scene.physicsWorld.add(addJointRtBa)
//        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
 
}
