//
//  TutorialBalloon.swift
//  Pop Balloon
//
//  Created by Julia Rocha on 17/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit
import AVFoundation

class TutorialBalloon:SKSpriteNode {
    var player1:AVAudioPlayer?
    let rope = SKShapeNode()
    
    init(scene:SKScene) {
        let myTexture = SKTexture(imageNamed: "red")
        super.init(texture: myTexture, color: .clear, size: myTexture.size())
        self.position = CGPoint(x: -25, y: 135)
        self.setScale(1.5)
        self.zPosition = 5
        let startPoint = CGPoint(x: self.position.x, y: self.position.y - 80)
        let endPoint = CGPoint(x: 0, y: -300)
        let path = UIBezierPath()
        path.move(to: startPoint)
        path.addLine(to: endPoint)
        self.rope.path = path.cgPath
        self.rope.strokeColor = UIColor.black
        self.rope.lineWidth = 2
        scene.addChild(self.rope)
        self.rope.zPosition = 4
        self.name = "tutorialBalloon"
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var pop:Void {
        let popFrames:[SKTexture] = [SKTexture(imageNamed: "red2"), SKTexture(imageNamed: "red3"), SKTexture(imageNamed: "red4")]
        let popAnime = SKAction.run {
            self.run(SKAction.repeat(SKAction.animate(with: popFrames, timePerFrame: 1, resize: false, restore: false), count: 1))
            self.popSound()
        }
        let popToAlem = SKAction.run {
            self.alpha = 0
            self.rope.alpha = 0
        }
        
        let finalSequence = SKAction.sequence([popAnime, popToAlem])
        self.run(finalSequence)
    }
    
    //SOM DO BALAO
    func popSound() {
        guard let url = Bundle.main.url(forResource: "pop", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player1 = try AVAudioPlayer(contentsOf: url, fileTypeHint: "mp3")
            
            guard let player = player1 else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
}
