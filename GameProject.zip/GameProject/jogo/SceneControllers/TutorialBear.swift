//
//  TutorialBear.swift
//  Pop Balloon
//
//  Created by Julia Rocha on 17/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit


class TutorialBear:SKSpriteNode {
    
    init() {
        
        let myTexture = SKTexture(imageNamed: "olar_00")
        super.init(texture: myTexture, color: .clear, size: myTexture.size())
        self.position = CGPoint(x: 150, y: -410)
        self.zPosition = 3
        self.setScale(0.3)
        self.name = "tutorialBear"
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    
    
    var makeHello:Void{
        var myTextureName:String
        var helloTextures:[SKTexture] = []
        for i in 0 ... 16 {
            myTextureName = "olar_0\(i)"
            helloTextures.append(SKTexture(imageNamed: myTextureName))
        }
        let makeHappy = SKAction.run {
            self.run(SKAction.repeat(SKAction.animate(with: helloTextures, timePerFrame: 0.2, resize: false, restore: true), count: 3))
        }
        run(makeHappy
        )
    }
    
    
    var makeSad:Void{
        var myTextureName:String
        var sadTextures:[SKTexture] = []
        for i in 16 ... 39 {
            myTextureName = "gooodbye_0\(i)"
            sadTextures.append(SKTexture(imageNamed: myTextureName))
        }
        let makeSad = SKAction.run {
            self.run(SKAction.repeat(SKAction.animate(with: sadTextures, timePerFrame: 0.2, resize: false, restore: false), count: 1))
        }
        run(makeSad)
    }
}

