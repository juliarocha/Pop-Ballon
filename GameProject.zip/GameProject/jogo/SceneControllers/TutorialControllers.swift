//
//  TutorialControllers.swift
//  Pop Balloon
//
//  Created by Julia Rocha on 17/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit

class TutorialControllers {
    
    let possibleYs:[Int] = [400, 75, 160, 160, 280, 0]
    let goNode:SKSpriteNode?
    let backNode:SKSpriteNode?
    
    init(page:Int, scene:SKScene) {
        
        self.backNode = SKSpriteNode(imageNamed: "backTT")
        self.goNode = SKSpriteNode(imageNamed: "goTT")
        let pageY = self.possibleYs[page-1]
        backNode?.position = CGPoint(x: -150, y: pageY)
        goNode?.position = CGPoint(x: 150, y: pageY)
        backNode?.zPosition = 4
        goNode?.zPosition = 4
        backNode?.name = "tutorialBack"
        goNode?.name = "tutorialGo"
        switch page {
        case 1:
            scene.addChild(goNode!)
            goNode?.position = CGPoint(x: 0, y: pageY)
        case 6:
            break
        default:
            scene.addChild(backNode!)
            scene.addChild(goNode!)
        }
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
