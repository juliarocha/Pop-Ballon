//
//  TutorialScene.swift
//  jogo
//
//  Created by Julia Rocha on 19/05/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//


import SpriteKit
import GameplayKit
import AVFoundation

class TutorialScene: SKScene {
  
    
    private var pageCount = 1

    
    override func didMove(to view: SKView) {
        displayTutorial(page: self.pageCount)
    }
    
  
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch:UITouch = touches.first!
        let positionInScene = touch.location(in: self)
        let touchedNode = self.atPoint(positionInScene)
        
        if touchedNode.name == "tutorialGo"{
                self.removeAllChildren()
                self.pageCount += 1
                displayTutorial(page: self.pageCount)
        }
        if touchedNode.name == "tutorialBack"{
            if self.pageCount == 1 {
                let goNext = SKAction.run {
                    let newScene = BeginScene(fileNamed: "BeginScene")
                    newScene?.scaleMode = .aspectFill
                    self.scene?.view?.presentScene(newScene!, transition: SKTransition.fade(withDuration: 1))
                }
                run(goNext)
            }
            self.removeAllChildren()
            self.pageCount -= 1
            displayTutorial(page: self.pageCount)
        }
        
        if let balloon = touchedNode as? TutorialBalloon {
            
            let pop = SKAction.run {
                balloon.pop
            }
            let wait = SKAction.wait(forDuration: 0.5)

            let transition = SKAction.run {
                    let newScene = GameScene(fileNamed: "GameScene")
                    newScene?.scaleMode = .aspectFill
                    self.scene?.view?.presentScene(newScene!, transition: SKTransition.fade(withDuration: 1))
            }
            
            let finalSequence = SKAction.sequence([pop, wait, transition])
            self.run(finalSequence)
            
        }
        
        if touchedNode.name == "backGame" {
            let goNext = SKAction.run {
                let newScene = BeginScene(fileNamed: "BeginScene")
                newScene?.scaleMode = .aspectFill
                self.scene?.view?.presentScene(newScene!, transition: SKTransition.fade(withDuration: 1))
            }
            run(goNext)
            
        }

    
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
    
    
    func displayTutorial(page:Int) {
        let page = TutorialScenes(page: page, scene: self)
        self.addChild(page)
        
        let backButton = BackButton()
        self.addChild(backButton)
        
    }
    
    
    
}
