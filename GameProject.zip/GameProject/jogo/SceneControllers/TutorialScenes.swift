//
//  TutorialScenes.swift
//  Pop Balloon
//
//  Created by Julia Rocha on 17/08/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import Foundation
import SpriteKit

class TutorialScenes:SKSpriteNode {
    
    let myTutorialTextures:[SKTexture] = [SKTexture(imageNamed: "tt1"), SKTexture(imageNamed: "tt2"), SKTexture(imageNamed: "tt3"), SKTexture(imageNamed: "tt4"), SKTexture(imageNamed: "tt5"), SKTexture(imageNamed: "tt6")]
    
    init(page:Int, scene:SKScene) {
        
        let myTexture = myTutorialTextures[page-1]
        super.init(texture: myTexture, color: .clear, size: myTexture.size())
        self.size = scene.size
        self.position = CGPoint(x: self.position.x, y: self.position.y + 50)
        self.zPosition = 2
        let controllers = TutorialControllers(page: page, scene: scene)
        let bear = TutorialBear()
        scene.addChild(bear)
        
        
        switch page {
        case 4:
            bear.makeSad
        case 5:
            bear.makeSad
        case 6:
            bear.removeFromParent()
            controllers.backNode?.removeFromParent()
            controllers.goNode?.removeFromParent()
            let balloon = TutorialBalloon(scene: scene)
            scene.addChild(balloon)
            
        default:
            bear.makeHello
        }
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
