//
//  tutorial.swift
//  jogo
//
//  Created by Julia Rocha on 19/05/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//

import SpriteKit
import GameplayKit
import AVFoundation

class tutorial: SKScene {
    
    private var tt1:SKSpriteNode?
    private var tt2:SKSpriteNode?
    private var tt3:SKSpriteNode?
    private var tt4:SKSpriteNode?

    
    override func didMove(to view: SKView) {
        self.tt1 = self.childNode(withName: "//tt1") as?  SKSpriteNode
        self.tt2 = self.childNode(withName: "//tt2") as?  SKSpriteNode
        self.tt3 = self.childNode(withName: "//tt3") as?  SKSpriteNode
        self.tt4 = self.childNode(withName: "//tt4") as?  SKSpriteNode
   
        
        tt1?.position = CGPoint(x: 0, y: 0)
        tt2?.position = CGPoint(x: 0, y: 0)
        tt3?.position = CGPoint(x: 0, y: 0)
        tt4?.position = CGPoint(x: 0, y: 0)
     
        tt1?.zPosition = 1
        tt2?.zPosition = 0
        tt3?.zPosition = 0
        tt4?.zPosition = 0
        
        
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch:UITouch = touches.first!
        let positionInScene = touch.location(in: self)
        let touchedNode = self.atPoint(positionInScene)
        
        if (touchedNode.name == "tt1") {
            tt1?.zPosition = 0
            tt2?.zPosition = 1
        }
        
        if (touchedNode.name == "tt2") {
            tt2?.zPosition = 0
            tt3?.zPosition = 1
        }
        if (touchedNode.name == "tt3") {
            tt3?.zPosition = 0
            tt4?.zPosition = 1
        }
        if (touchedNode.name == "tt4") {
            //GO TO GameScene
        }
        
    }
    
    

    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
