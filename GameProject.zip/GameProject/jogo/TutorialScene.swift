//
//  TutorialScene.swift
//  jogo
//
//  Created by Julia Rocha on 19/05/2018.
//  Copyright © 2018 Julia Rocha. All rights reserved.
//


import SpriteKit
import GameplayKit
import AVFoundation

class TutorialScene: SKScene {
    
    
    private var tt1:SKSpriteNode?
    private var tt2:SKSpriteNode?
    private var tt3:SKSpriteNode?
    private var tt4:SKSpriteNode?
    private var tt5:SKSpriteNode?
    private var tt6:SKSpriteNode?
    private var bear:SKSpriteNode?
    private var back:SKSpriteNode?

    

    
    override func didMove(to view: SKView) {
        
        
        
        self.tt1 = self.childNode(withName: "//tt1") as?  SKSpriteNode
        self.tt2 = self.childNode(withName: "//tt2") as?  SKSpriteNode
        self.tt3 = self.childNode(withName: "//tt3") as?  SKSpriteNode
        self.tt4 = self.childNode(withName: "//tt4") as?  SKSpriteNode
        self.tt5 = self.childNode(withName: "//tt5") as?  SKSpriteNode
        self.tt6 = self.childNode(withName: "//tt6") as?  SKSpriteNode
        self.bear = self.childNode(withName: "//bear1") as? SKSpriteNode
        self.back = self.childNode(withName: "back") as? SKSpriteNode
        
        
        tt1?.position = CGPoint(x: 0, y: 0)
        tt2?.position = CGPoint(x: 0, y: 0)
        tt3?.position = CGPoint(x: 0, y: 0)
        tt4?.position = CGPoint(x: 0, y: 0)
        tt5?.position = CGPoint(x: 0, y: 0)
        tt6?.position = CGPoint(x: 0, y: 0)
        bear?.position = CGPoint(x: 120, y: -450)
        bear?.setScale(0.35)
        back?.position = CGPoint(x: -300, y: 640)
        back?.zPosition = 6
        back?.name = "back"
        
        
        
        tt1?.zPosition = 1
        bear?.zPosition = 3
        tt2?.zPosition = 0
        tt3?.zPosition = 0
        tt4?.zPosition = 0
        tt5?.zPosition = 0
        tt6?.zPosition = 0

        self.makeHello
        
    }
    
    var helloBearFrames:[SKTexture] {
        var myTextureName:String
        var helloTextures:[SKTexture] = []
        for i in 0 ... 16 {
            myTextureName = "olar_0\(i)"
            helloTextures.append(SKTexture(imageNamed: myTextureName))
        }
        return helloTextures
    }
    
    var sadBearFrames:[SKTexture] {
        var myTextureName:String
        var sadTextures:[SKTexture] = []
        for i in 16 ... 39 {
            myTextureName = "gooodbye_0\(i)"
            sadTextures.append(SKTexture(imageNamed: myTextureName))
        }
        return sadTextures
    }
    
    
    var makeHello:Void{
        let makeHappy = SKAction.run {
            self.bear?.run(SKAction.repeat(SKAction.animate(with: self.helloBearFrames, timePerFrame: 0.2, resize: false, restore: true), count: 3))
        }
        run(makeHappy
        )
    }
    var makeSad:Void{
        let makeSad = SKAction.run {
            self.bear?.run(SKAction.repeat(SKAction.animate(with: self.sadBearFrames, timePerFrame: 0.2, resize: false, restore: false), count: 1))
        }
        run(makeSad)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch:UITouch = touches.first!
        let positionInScene = touch.location(in: self)
        let touchedNode = self.atPoint(positionInScene)
        
        
        if (touchedNode.name == "tt1") {
            SKAction.wait(forDuration: 0.3)
                self.tt1?.zPosition = -5
                self.bear?.zPosition = 2
                self.tt2?.zPosition = 1
        }
        
        if (touchedNode.name == "tt2") {
            SKAction.wait(forDuration: 0.3)
            self.tt2?.zPosition = -4
            self.bear?.zPosition = 2
            self.tt3?.zPosition = 1
        }
        if (touchedNode.name == "tt3") {
            SKAction.wait(forDuration: 0.3)
            self.tt3?.zPosition = -3
            self.bear?.zPosition = 2
            self.tt4?.zPosition = 1
        }
        if (touchedNode.name == "tt4") {
            SKAction.wait(forDuration: 0.3)
            self.tt4?.zPosition = -2
            self.bear?.zPosition = 2
            self.makeSad
            self.tt5?.zPosition = 1
        }
        if (touchedNode.name == "tt5") {
            SKAction.wait(forDuration: 0.3)
            self.tt5?.zPosition = -1
            self.bear?.zPosition = 0
            self.tt6?.zPosition = 1
        }
        
        if touchedNode.name == "back" {
            let goNext = SKAction.run {
                let newScene = BeginScene(fileNamed: "BeginScene")
                newScene?.scaleMode = .aspectFill
                self.scene?.view?.presentScene(newScene!, transition: SKTransition.doorsCloseHorizontal(withDuration: 1))
            }
            run(goNext)
        }
        
          if (touchedNode.name == "tt6") {
        //SCENE TRANSITION
        let goNext = SKAction.run {
            let newScene = TutorialScene(fileNamed: "GameScene")
            newScene?.scaleMode = .aspectFill
            self.scene?.view?.presentScene(newScene!, transition: SKTransition.fade(withDuration: 1))
        }
        run(goNext)
        }
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
